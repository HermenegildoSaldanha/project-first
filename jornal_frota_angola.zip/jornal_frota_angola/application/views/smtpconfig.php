  <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Configuração de SMTP
            </h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url(); ?>/dashboard">Home</a></li>
              <li class="breadcrumb-item active">Configuração de SMTP</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- Main content -->
<section class="content">
  <div class="container-fluid">
  
<div class="card">
              
           <div class="row">
              <div class="col-sm-3"></div> 
                <div class="col-sm-6 col-md-offset-2 ">
              <form id="addnewcategory" class="basicvalidation" role="form" action="<?php echo base_url(); ?>settings/smtpconfigsave" method="post"  enctype='multipart/form-data'>
                <div class="card-body">
                  <div class="form-group">
                    <label>Host</label>
                    <input type="text" class="form-control" required="true" value="<?php echo output(isset($smtpconfig[0]['smtp_host'])?$smtpconfig[0]['smtp_host']:''); ?>" id="smtp_host" name="smtp_host" placeholder="Entrar com Host">
                  </div>

                  <div class="form-group">
                     <label>SMTPAuth</label>
                     <select class="form-control" id="smtp_auth" required="true" name="smtp_auth">
                      <option value="">Selecione SMTPAuth</option>
                      <option <?php echo (isset($smtpconfig[0]['smtp_auth']) && $smtpconfig[0]['smtp_auth']=='true') ? 'selected':'' ?> value="true">True</option>
                      <option <?php echo (isset($smtpconfig[0]['smtp_auth']) && $smtpconfig[0]['smtp_auth']=='false') ? 'selected':'' ?> value="false">False</option>
                    </select>

                  </div>

                  <div class="form-group">
                    <label>Usuário</label>
                    <input type="text" class="form-control" required="true" value="<?php echo output(isset($smtpconfig[0]['smtp_uname'])?$smtpconfig[0]['smtp_uname']:''); ?>" id="smtp_uname" name="smtp_uname" placeholder="Entrar com Usuário">
                  </div>


                   <div class="form-group">
                    <label>Password</label>
                    <input type="password" class="form-control" required="true" value="<?php echo output(isset($smtpconfig[0]['smtp_pwd'])?$smtpconfig[0]['smtp_pwd']:''); ?>" id="s_inovicess_prefix" name="smtp_pwd" placeholder="Entrar com Palavra-passe de SMTP">
                  </div>

                   <div class="form-group">
                    <label>SMTPSecure</label>
                      <select class="form-control" id="smtp_issecure" required="true" name="smtp_issecure">
                      <option value="">Selecione SMTP Secure</option>
                      <option <?php echo (isset($smtpconfig[0]['smtp_issecure']) && $smtpconfig[0]['smtp_issecure']=='ssl') ? 'selected':'' ?> value="ssl">SSL</option>
                      <option <?php echo (isset($smtpconfig[0]['smtp_issecure']) && $smtpconfig[0]['smtp_issecure']=='tls') ? 'selected':'' ?> value="tls">TLS</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Porta</label>
                    <input type="text" class="form-control" required="true" value="<?php echo output(isset($smtpconfig[0]['smtp_port'])?$smtpconfig[0]['smtp_port']:''); ?>" id="smtp_port" name="smtp_port" placeholder="Entrar com a Porta">
                  </div>
                  
                  <div class="form-group">
                    <label>E-mail de</label>
                    <input type="text" class="form-control" required="true" value="<?php echo output(isset($smtpconfig[0]['smtp_emailfrom'])?$smtpconfig[0]['smtp_emailfrom']:''); ?>" id="smtp_emailfrom" name="smtp_emailfrom" placeholder="Entrar E-mail de Origem">
                  </div>
                  <div class="form-group">
                    <label>Responder a</label>
                    <input type="text" class="form-control" required="true" value="<?php echo output(isset($smtpconfig[0]['smtp_emailfrom'])?$smtpconfig[0]['smtp_emailfrom']:''); ?>" id="smtp_replyto" name="smtp_replyto" placeholder="Entrar com Responder">
                  </div> 
               
                    <div class="modal-footer justify-content-between">
                    <button type="button" data-toggle="modal" data-target="#modal-default" class="btn btn-primary">Teste E-mail</button>
                    <button type="submit" class="btn btn-primary">Salvar a Configuração</button>
                  </div>

                </div>
              </form>
            </div>
            </div>
          </div>
</section>


<div class="modal fade show" id="modal-default" aria-modal="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Teste de Configuration de SMTP</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
       <form   action="<?php echo base_url(); ?>settings/smtpconfigtestemail" method="post" >
      <div class="modal-body">
        <div class="form-group row">
              <label for="inputEmail3" class="col-sm-2 col-form-label">E-mail</label>
              <div class="col-sm-10">
              <input type="email" required="true" class="form-control" id="testemailto" name="testemailto" placeholder="Entrar E-mail">
              </div>
            </div>            
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
        <button type="submit" class="btn btn-primary">Enviar E-mail</button>
      </div>
          </form>

    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>