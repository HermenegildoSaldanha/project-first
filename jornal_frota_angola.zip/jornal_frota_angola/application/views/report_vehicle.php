<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1 class="m-0 text-dark">Relatório Veículo
            </h1>
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?= base_url(); ?>reports">Relatório</a></li>
               <li class="breadcrumb-item active">Relatório de Veículo</li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
<!-- Main content -->
<section class="content">
   <div class="container-fluid">
      <form method="post" id="fuel_report" class="card basicvalidation" action="<?php echo base_url();?>reports/vehicles">
         <div class="card-body">
            <div class="row">
               <div class="col-md-3">
                  <div class="form-group row">
                     <label for="fuel_from" class="col-sm-5 col-form-label">Relatório de</label>
                     <div class="col-sm-6 form-group">
                        <input type="text" required="true" class="form-control form-control-sm datepicker" value="<?php echo isset($_POST['fuel_from']) ? $_POST['fuel_from'] : ''; ?>" id="fuel_from" name="fuel_from" placeholder="Data de">
                     </div>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="form-group row">
                     <label for="fuel_to" class="col-sm-5 col-form-label">Relótorio para</label>
                     <div class="col-sm-6 form-group">
                        <input type="text" required="true" class="form-control form-control-sm datepicker" value="<?php echo isset($_POST['fuel_to']) ? $_POST['fuel_to'] : ''; ?>" id="fuel_to" name="fuel_to" placeholder="Data para">
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="form-group row">
                     <label for="booking_to" class="col-sm-3 col-form-label">Veículo</label>
                     <div class="col-sm-8 form-group">
                        <select required="true" id="vechicle"  class="form-control selectized"  name="fuel_vechicle">
                           <option value="all">Todos os Vículos</option>
                           <?php foreach ($vehiclelist as $key => $vechiclelists) { ?>
                           <option <?php echo (isset($_POST['booking_vechicle']) && ($_POST['booking_vechicle'] == $vechiclelists['v_id'])) ? 'selected':'' ?> value="<?php echo output($vechiclelists['v_id']) ?>"><?php echo output($vechiclelists['v_name']).' - '. output($vechiclelists['v_registration_no']); ?></option>
                           <?php  } ?>
                        </select>
                     </div>
                  </div>
               </div>
               <input type="hidden" id="fuelreport" name="fuelreport" value="1">
               <div class="col-md-2">
                  <button type="submit" class="btn btn-block btn-outline-info btn-sm"> Gerar relatório</button>
               </div>
            </div>
         </div>
   </div>
   </form>
    <div class="card">
        <div class="card-body p-0">

            <?php if(!empty($fuel)){ 
             ?>
   <!-- <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">  
               <div class="dt-buttons">      <button class="dt-button buttons-copy buttons-html5" tabindex="0" aria-controls="DataTables_Table_0" type="button"><span>Copy</span></button> <button class="dt-button buttons-excel buttons-html5" tabindex="0" aria-controls="DataTables_Table_0" type="button"><span>Excel</span></button> <button class="dt-button buttons-csv buttons-html5" tabindex="0" aria-controls="DataTables_Table_0" type="button"><span>CSV</span></button> <button class="dt-button buttons-pdf buttons-html5" tabindex="0" aria-controls="DataTables_Table_0" type="button"><span>PDF</span></button> </div>
  </div> -->
                   <table  class="datatableexport table card-table">
                      <thead>
                        <tr>
                          <th class="w-1">S.No</th>
                           <th>Marca</th>
                          <th>Modelo</th>
                          <th>Matricula</th>
                          <th>Cor</th>
                          <th>Nº de Chassi</th>
                          <th>Grupo/Actuação</th>
                           <th>Ano de Compra</th>
                          <th>Tempo de Uso</th>
                          <th>Motorista</th>
                          <th>Província</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                       //var_dump($fuel);
                      if(!empty($fuel)){  $count=1;
                           foreach($fuel as $fuels){
                           ?>
                        <tr>
                           <td> <?php echo output($count); $count++; ?></td>
                           <td> <?php echo output($fuels['v_name']); ?></td>
                           <td> <?php echo output($fuels['v_model']); ?></td>
                           <td> <?php echo output($fuels['v_registration_no']); ?></td>
                           <td style="background-color: <?=output($fuels['v_color'])?>;"><?php echo output($fuels['v_color']); ?></td>                           <td><?php echo output($fuels['v_chassis_no']); ?></td>
                           <td><?php echo output($fuels['group']->gr_name); ?></td>
                           <td><?php  $data="".date('Y', strtotime($fuels['v_compra']));  if(isset($fuels['v_compra']) && $data !="1970"){ echo date('Y', strtotime($fuels['v_compra']));}else{ echo " ";} ?></td>
                           <td><?php  
                           if($data!="1970" && isset($data)){
                            $data_uso = date('Y')- date('Y', strtotime($fuels['v_compra']));
                           echo  $data_uso;} else{echo ""; }
                          ?></td>
                           
                           <td><?php  if (isset($fuels['filled_by']->d_name) ){echo output($fuels['filled_by']->d_name);}?></td>
                           <td><?php if (isset(($fuels['v_province']))){ echo $fuels['v_province'];} ?></td>

                        </tr>
                        <?php } } ?>
                      </tbody>
                    </table>
                     <?php }  ?>
        </div>
      </div>
   </div>
</section>
 <script src="http://localhost/jornal_frota_angola/assets/plugins/datatables/dataTables.buttons.min.js"></script>

<script src="http://localhost/jornal_frota_angola/assets/plugins/datatables/jszip.min.js"></script>
<script src="http://localhost/jornal_frota_angola/assets/plugins/datatables/pdfmake.min.js"></script>
<script src="http://localhost/jornal_frota_angola/assets/plugins/datatables/vfs_fonts.js"></script>
<script src="http://localhost/jornal_frota_angola/assets/plugins/datatables/buttons.html5.min.js"></script>
<!-- <script src="http://localhost/jornal_frota_angola/assets/custom.js?v=<?= mt_rand(); ?>"></script>-->
