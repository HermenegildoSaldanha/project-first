  <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Modelo de e-mail
            </h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url(); ?>/dashboard">Home</a></li>
              <li class="breadcrumb-item active">Modelo de e-mail</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- Main content -->
<section class="content">
  <div class="container-fluid">
<div class="card">
    <div class="row">
      <div class="col-sm-3"></div> 
        <div class="col-sm-6 col-md-offset-2 ">
      <form id="addnewcategory" class="basicvalidation" role="form" action="<?php echo base_url(); ?>settings/update_template" method="post"  enctype='multipart/form-data'>
        <div class="card-body">
          <div class="form-group">
            <label>Nome</label>
            <input type="text" class="form-control" readonly required="true" value="<?php echo output(isset($emailtemplate[0]['et_name'])?$emailtemplate[0]['et_name']:''); ?>" id="et_name" name="et_name" placeholder="Insira o nome">
          </div>
          <div class="form-group">
            <label>Conteúdo</label>
            <textarea class="form-control" rows="10" id="et_body" name="et_body" placeholder="Email content"><?php echo output(isset($emailtemplate[0]['et_body'])?$emailtemplate[0]['et_body']:''); ?></textarea>
          </div>
          <input type="hidden" required="true" class="form-control" value="<?php echo output(isset($emailtemplate[0]['et_id'])?$emailtemplate[0]['et_id']:''); ?>" id="et_id" name="et_id" >
            <small>Observação: use a tag "p" para cada nova linha.</small>
            <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Atualizar</button>
          </div>
        </div>
      </form>
    </div>
    </div>
</section>   


