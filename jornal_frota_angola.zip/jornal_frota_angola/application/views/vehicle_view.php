 
      
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Detalhes do veículo
            </h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url(); ?>/dashboard">Home</a></li>
              <li class="breadcrumb-item active">Detalhes do veículo</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
      
    <!-- Main content -->
  <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3">

            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                 
                </div>

                <h3 class="profile-username text-center"><?= ucwords($vehicledetails['v_name']); ?></h3>

                <p class="text-muted text-center"><?= ucwords($vehicledetails['v_type']); ?></p>

                <p class="text-muted text-center">

                <?php
            
            
switch ($vehicledetails['v_is_active']) {
 case '1':
    echo ' <span class="right badge badge-success ">   Activo </span>';
    break;
 
    case '0':
       echo '<span class="right badge badge-warning ">  Inactivo </span>';
       break;

  case '2':
       echo '<span class="right badge badge-secondary ">  Reparação/Avariado </span>';
   break;

   case '3':
    echo '<span class="right badge badge-danger ">   Abato </span>';
break;

 default:
 echo "não variavel";
    break;
}
 ?> 
</p>


                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b>Reservas</b> <a class="float-right"><?= count($bookings); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>cerca geográfica</b> <a class="float-right"><?= count($vechicle_geofence); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Notificações</b> <a class="float-right"><?= count($geofence_events); ?></a>
                  </li>
                </ul>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

           
          </div>
          <!-- /.col -->
          <div class="col-md-9">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                   <li class="nav-item"><a class="nav-link active" href="#basicinfo" data-toggle="tab">Informação básica</a></li>
                  <li class="nav-item"><a class="nav-link " href="#bookings" data-toggle="tab">Reservas</a></li>
                  <li class="nav-item"><a class="nav-link" href="#vechicle_geofence" data-toggle="tab">Cerca geográfica</a></li>
                <li class="nav-item"><a class="nav-link" href="#vechicle_incomexpense" data-toggle="tab">Receita e Despesa</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="tab-pane " id="bookings">
                     <table id="bookingstbl" class="table table-striped projects">
                          <thead>
                              <tr>
                                  <th class="percent1">
                                      #
                                  </th>
                                  <th class="percent25">
                                  Condutor
                                  </th>
                                  <th class="percent25">
                                      Cliente
                                  </th>
                                  <th class="percent25">
                                  De para
                                  </th>
                                  <th class="percent25">
                                  Valor da reserva
                                  </th>
                                 
                                  <th class="percent25">
                                  Status da viagem
                                  </th>
                                  <th class="percent25">
                                    Acção
                                  </th>
                              </tr>
                          </thead>
                          <tbody>
                            <?php if(!empty($bookings)) {
                            $count=1;
                            foreach($bookings as $bookingsdata){
                            ?>
                              <tr>
                                  <td>
                                     <?php echo output($count); $count++; ?>
                                  </td>
                                   <td><?= (isset($bookingsdata['t_driver_details']->d_name))?$bookingsdata['t_driver_details']->d_name:'<span class="badge badge-danger">Ainda para atribuir</span>'; ?></td>
                                  <td>
                                     <?php echo output($bookingsdata['t_customer_details']->c_name);?>
                                  </td>
                                  <td>
                                     <?php echo '<small>'.output($bookingsdata['t_trip_fromlocation']).'</small>'; echo '<br><span class="badge badge-success">Para</span><br>';?>
                                     <?php echo '<small>'.output($bookingsdata['t_trip_tolocation']).'</small>';?>
                                  </td>
                                  <td>
                                     <?php echo output($bookingsdata['t_trip_amount']);?>
                                  </td>
                                  
                                   <td>
                                   <?php 
                                     switch($bookingsdata['t_trip_status']){
                                        case 'ongoing':
                                            $status = '<span class="badge badge-info">Em andamento</span>';
                                            break;
                                        case 'completed':
                                            $status = '<span class="badge badge-success">Concluído</span>';
                                             break;
                                        case 'yettostart':
                                            $status = '<span class="badge badge-warning">Ainda para começar</span>';
                                             break;
                                        case 'cancelled':
                                            $status = '<span class="badge badge-danger">Cancelado</span>'; 
                                             break; 
                                        case 'yettoconfirm':
                                            $status = '<span class="badge badge-danger">ainda para confirmar</span>'; 
                                             break;    
                                      }

                                      ?>
                                     <?=  $status ?>  
                                  </td>
                                  <td> <a class="icon" target="_blank" href="<?php echo base_url(); ?>trips/details/<?php echo output($bookingsdata['t_id']); ?>">
                                     <i class="fa fa-eye"></i>
                                    </a> 
                                  </td>
                              </tr>
                              <?php } } ?>
                          </tbody>
                      </table>

                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="vechicle_geofence">
                    <!-- The timeline -->
                    <table id="vgeofencetbl" class="table table-striped projects">
                          <thead>
                              <tr>
                                  <th class="percent1">
                                      #
                                  </th>
                                  <th class="percent25">
                                      Nome
                                  </th>
                                  <th class="percent25">
                                      Descrição
                                  </th>
                                 <th class="percent25">
                                    Acção
                                </th>
                                  
                              </tr>
                          </thead>
                          <tbody>
                            <?php if(!empty($vechicle_geofence)){ 
                            $count=1;
                            foreach($vechicle_geofence as $vechicle_geofence){
                            ?>
                              <tr>
                                  <td>
                                     <?php echo output($count); $count++; ?>
                                  </td>
                                  <td>
                                      <?php echo output($vechicle_geofence['geo_name']);?>
                                  </td>
                                  <td>
                                     <?php echo output($vechicle_geofence['geo_description']);?>
                                  </td>
                                  <td> <a class="icon" href="<?php echo base_url(); ?>geofence">
                                     <i class="fa fa-eye"></i>
                                    </a> 
                                  </td>
                              </tr>
                          <?php } } ?>
                          </tbody>
                      </table>
                  </div>

                  <div class="tab-pane" id="vechicle_incomexpense">
                     <table id="incomexpenstbl" class="table table-striped projects">
                          <thead>
                              <tr>
                                  <th class="percent1">
                                      #
                                  </th>
                                  <th class="percent25">
                                      Data
                                  </th>
                                  <th class="percent25">
                                      Descrição
                                  </th>
                                  <th class="percent25">
                                  Montante
                                  </th>
                                  <th class="percent25">
                                      Tipo
                                  </th>
                                  <th class="percent25">
                                    Acção
                                  </th>
                              </tr>
                          </thead>
                          <tbody>
                            <?php if(!empty($vechicle_incomexpense)){ 
                            $count=1;
                            foreach($vechicle_incomexpense as $incomexpensdata){
                            ?>
                              <tr>
                                  <td>
                                     <?php echo output($count); $count++; ?>
                                  </td>
                                  <td>
                                      <?php echo output($incomexpensdata['ie_date']);?>
                                  </td>
                                  <td>
                                     <?php echo output($incomexpensdata['ie_description']);?>
                                  </td>
                                  <td>
                                     <?php echo output($incomexpensdata['ie_amount']);?>
                                  </td>
                                  <td>
                                     <?php echo ($incomexpensdata['ie_type']=='income')?'<span class="right badge badge-success">Income</span>':'<span class="right badge badge-danger">Despesa</span>'; ?>
                                  </td>
                                 <td> <a class="icon" href="<?php echo base_url(); ?>incomexpense">
                                     <i class="fa fa-eye"></i>
                                    </a> 
                                  </td>                                 
                              </tr>
                          <?php } } ?>
                          </tbody>
                      </table>
                  </div>
                  <!-- /.tab-pane -->

                  <div class="tab-pane active" id="basicinfo">
                    <table class="table table-sm table-bordered">
                  <tbody>
                    <tr>
                      <td>Matricula</td>
                      <td><?= output($vehicledetails['v_registration_no']) ?></td>
                    </tr>
                    <tr>
                      <td>Marca</td>
                      <td><?= output($vehicledetails['v_name']) ?></td>
                    </tr>
                    <tr>
                      <td>Modelo</td>
                      <td><?= output($vehicledetails['v_model']) ?></td>
                    </tr>
                    <tr>
                      <td>Número de chassi.</td>
                      <td><?= output($vehicledetails['v_chassis_no']) ?></td>
                    </tr>
                    <tr>
                      <td>Parqueamento</td>
                      <td><?= output($vehicledetails['v_manufactured_by']) ?></td>
                    </tr>
                    <tr>
                      <td>Marca</td>
                      <td><?= output($vehicledetails['v_name']) ?></td>
                    </tr>
                     <tr>
                      <td>Tipo de viatura</td>
                      <td><?= output($vehicledetails['v_type']) ?></td>
                    </tr>
                    <!-- <tr>
                      <td>Quilometragem/Litro</td>
                      <td><?= output($vehicledetails['v_mileageperlitre']) ?></td>
                    </tr>-->
                     <tr>
                      <td>API URL</td>
                      <td><?= output($vehicledetails['v_api_url']) ?></td>
                    </tr>
                     <tr>
                      <td>GPS API Username</td>
                      <td><?= output($vehicledetails['v_api_username']) ?></td>
                    </tr>
                     <tr>
                      <td>GPS API Password</td>
                      <td><?= output($vehicledetails['v_api_password']) ?></td>
                    </tr>
                     <tr>
                      <td>Data de Criação</td>
                      <td><?= output($vehicledetails['v_created_date']) ?></td>
                    </tr>
                     <tr>
                      <td>Data de Modificação</td>
                      <td><?= output($vehicledetails['v_modified_date']) ?></td>
                    </tr>
                  </tbody>
                </table>
                <div class="col-sm-3">
                  <a href="<?= base_url(); ?>vehicle/editvehicle/<?= $vehicledetails['v_id']; ?>">
                   <button type="button" class="btn btn-block btn-success btn-sm">Editar Informação</button>
                 </a>
                </div>
                  </div>
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
