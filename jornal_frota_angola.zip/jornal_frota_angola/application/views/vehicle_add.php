    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark"><?php echo (isset($vehicledetails))?'Editar Veículo':'Adicionar Veículo' ?>
            </h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url(); ?>/dashboard">Veículo</a></li>
              <li class="breadcrumb-item active"><?php echo (isset($vehicledetails))?'Editar Veículo':'Adicionar Veículo' ?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <form method="post" id="vehicle_add" class="card" action="<?php echo base_url();?>vehicle/<?php echo (isset($vehicledetails))?'updatevehicle':'insertvehicle'; ?>">
                <div class="card-body">


                 <div class="row">
                   <input type="hidden" name="v_id" id="v_id" value="<?php echo (isset($vehicledetails)) ? $vehicledetails[0]['v_id']:'' ?>" >

                    <div class="col-sm-6 col-md-4">
                        <label class="form-label">Matrícula</label>
                      <div class="form-group">
                        <input type="text" name="v_registration_no" id="v_registration_no" class="form-control" placeholder="Matrícula" value="<?php echo (isset($vehicledetails)) ? $vehicledetails[0]['v_registration_no']:'' ?>">
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <label class="form-label">Marca</label>
                      <div class="form-group">
                        <input type="text" name="v_name" id="v_name" class="form-control" placeholder="Marca do Veiculo" value="<?php echo (isset($vehicledetails)) ? $vehicledetails[0]['v_name']:'' ?>">
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label class="form-label">Modelo</label>
                        <input type="text" name="v_model" value="<?php echo (isset($vehicledetails)) ? $vehicledetails[0]['v_model']:'' ?>" class="form-control" placeholder="Modelo">
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label class="form-label">Número do chassi</label>
                        <input type="text" name="v_chassis_no" value="<?php echo (isset($vehicledetails)) ? $vehicledetails[0]['v_chassis_no']:'' ?>" class="form-control" placeholder="Número do chassi">
                      </div>
                    </div>
                     <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label class="form-label">Nº do motor</label>
                        <input type="text" name="v_engine_no" value="<?php echo (isset($vehicledetails)) ? $vehicledetails[0]['v_engine_no']:'' ?>" class="form-control" placeholder="Nº do motor">
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label class="form-label">Local de Parqueamento</label>
                        <input type="text" name="v_manufactured_by" value="<?php echo (isset($vehicledetails)) ? $vehicledetails[0]['v_manufactured_by']:'' ?>" class="form-control" placeholder="Local de Parqueamento">
                      </div>
                    </div>
                    
                         
                     <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label class="form-label">Tipo de Veículo</label>
                        <select id="v_type" name="v_type" class="form-control " required="">
                         <option value="">Selecione o tipo de veículo</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_type']=='CAR') ? 'selected':'' ?> value="CAR">Carro</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_type']=='MOTORCYCLE') ? 'selected':'' ?> value="MOTORCYCLE">Motorcicleta</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_type']=='TRUCK') ? 'selected':'' ?> value="TRUCK">Caminhão</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_type']=='BUS') ? 'selected':'' ?> value="BUS">Autocarros</option> 
                           <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_type']=='TAXI') ? 'selected':'' ?> value="TAXI">Táxi</option> 
                           <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_type']=='BICYCLE') ? 'selected':'' ?> value="BICYCLE">Bicicleta</option> 
                           <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_type']=='EMPILHADEIRA') ? 'selected':'' ?> value="EMPILHADEIRA">Empilhadeira</option> 
                        </select>

                      </div>
                    </div>

                    <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label for="v_color" class="form-label">cor do veículor<small> (Para mostrar no mapa)</small></label>
                        <input id="add-device-color" name="v_color" class="jscolor {valueElement:'add-device-color', styleElement:'add-device-color', hash:true, mode:'HSV'} form-control"  value="<?php echo (isset($vehicledetails)) ? $vehicledetails[0]['v_color']:'#F399EB' ?>" required>
                      </div>
                    </div>
                    <?php if(isset($vehicledetails[0]['v_is_active'])) { ?>
                    <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label for="v_is_active" class="form-label">Estado do veículo</label>
                        <select id="v_is_active" name="v_is_active" class="form-control " required="">
                          <option value="">Selecione o status do veículo</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_is_active']==1) ? 'selected':'' ?> value="1">Activo</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_is_active']==0) ? 'selected':'' ?> value="0">Inactivo</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_is_active']==2) ? 'selected':'' ?> value="2">Reparação/Avariados</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_is_active']==3) ? 'selected':'' ?> value="3">Abato</option> 
                        </select>
                      </div>
                    </div>
                  <?php } ?>

                  <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label class="form-label">Data de vencimento do registro</label>
                        <input type="text" required="" name="v_reg_exp_date" value="<?php echo (isset($vehicledetails)) ? $vehicledetails[0]['v_reg_exp_date']:'' ?>" class="form-control datepicker" placeholder="Data de vencimento do registro">
                      </div>
                  </div>
                  <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label class="form-label">Data de Compra</label>
                        <input type="text" required="" name="v_compra" value="<?php echo (isset($vehicledetails)) ? $vehicledetails[0]['v_compra']:'' ?>" class="form-control datepicker" placeholder="Data de Compra do Veículo">
                      </div>
                  </div> 
                   <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label for="v_group" class="form-label">Grupo de veículos</label>
                        <select id="v_group" name="v_group" class="form-control " required="">
                          <option value="">Selecione o grupo de veículos</option> 
                          <?php if(!empty($v_group)) { foreach($v_group as $v_groupdata) { ?>
                          <option <?= (isset($vehicledetails[0]['v_group']) && $vehicledetails[0]['v_group'] == $v_groupdata['gr_id'])?'selected':''?> value="<?= $v_groupdata['gr_id'] ?>"><?= $v_groupdata['gr_name'] ?></option> 
                          <?php } } ?>
                        </select>
                      </div>
                    </div>

                   <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label class="form-label">Província</label>
                        <select id="v_type"  name="v_province" class="form-control " required="">
                          <option value="">Selecione Província</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Bengo') ? 'selected':'' ?> value="Bengo">Bengo</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Benguela') ? 'selected':'' ?> value="Benguela">Benguela</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Bie') ? 'selected':'' ?> value="Bie">Bié</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Cabinda') ? 'selected':'' ?> value="Cabinda">Cabinda</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Cuando Cubango') ? 'selected':'' ?> value="Cuando Cubango">Cuando Cubango</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Cuanza Norte') ? 'selected':'' ?> value="Cuanza Norte">Cuanza Norte</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Cuanza Sul') ? 'selected':'' ?> value="Cuanza Sul">Cuanza Sul</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Cunene') ? 'selected':'' ?> value="Cunene">Cunene</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Huambo') ? 'selected':'' ?> value="Huambo">Huambo</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Huila') ? 'selected':'' ?> value="Huila">Huila</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Luanda') ? 'selected':'' ?> value="Luanda">Luanda</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Lunda Norte') ? 'selected':'' ?> value="Lunda Norte">Lunda Norte</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Lunda Sul') ? 'selected':'' ?> value="Lunda Sul">Lunda Sul</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Malanje') ? 'selected':'' ?> value="Malanje">Malanje</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Moxico') ? 'selected':'' ?> value="Moxico">Moxico</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Namibe') ? 'selected':'' ?> value="Namibe">Namibe</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Uige') ? 'selected':'' ?> value="Uige">Uige</option> 
                          <option <?php echo (isset($vehicledetails) && $vehicledetails[0]['v_province']== 'Zaire') ? 'selected':'' ?> value="Zaire">Zaire</option> 
                        </select>

                      </div>

                       <input type="hidden" name="v_criate_t" value="<?php echo date('Y-m-d h:i:s'); ?>">
                    </div>
                    </div>
                    <hr>
                    <div class="form-label"><b>Detalhes da API do GPS (Feed GPS Data)</b></div>
                     <div class="row">
                    <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label class="form-label">API URL</label>
                        <input type="text" name="v_api_url" class="form-control" placeholder="API URL" value="<?php echo base_url();?>api" readonly>
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label class="form-label">API Username</label>
                        <input type="text" id="v_api_username" value="<?php echo (isset($vehicledetails)) ? $vehicledetails[0]['v_api_username']:'' ?>" name="v_api_username" class="form-control" placeholder="API Username" readonly>
                      </div>
                    </div>
                  <div class="col-sm-6 col-md-4">
                      <div class="form-group">
                        <label class="form-label">API Password</label>
                        <input type="text" name="v_api_password" class="form-control" placeholder="API Password" value="<?php echo (isset($vehicledetails)) ? $vehicledetails[0]['v_api_password']:random_string('nozero', 6) ?>"  readonly>
                      </div>
                    </div>
                  </div>
                </div>
                  <input type="hidden" id="v_created_by" name="v_created_by" value="<?php echo output($this->session->userdata['session_data']['u_id']); ?>">
                   <input type="hidden" id="v_created_date" name="v_created_date" value="<?php echo date('Y-m-d h:i:s'); ?>">
               
               
               
               
               
               
               
               
               
               
               
                   <div class="card-footer text-right">
                  <button type="submit" class="btn btn-primary"> <?php echo (isset($vehicledetails))?'Atualizar veículo':'Adicionar veículo' ?></button>
                </div>
              </form>
             </div>
    </section>
    <!-- /.content -->



