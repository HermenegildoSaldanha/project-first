<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Frontendbooking extends CI_Controller {

	 function __construct()
     {
          parent::__construct();
          $this->load->database();
          $this->load->model('customer_model');
          $this->load->helper(array('form', 'url','string'));
          $this->load->library('form_validation');
          $this->load->library('session');
     }

	public function index()
	{
		$this->load->model('trips_model');
		$data['vechiclelist'] = $this->trips_model->getall_vechicle();
		$this->load->view('frontend_booking',$data);
	}
	public function mybookings()
	{
		$this->load->model('trips_model');
		$data['mybookings'] = $this->trips_model->getall_mybookings($this->session->userdata['session_data_fr']['c_id']);
		$this->load->view('frontend_booking_history',$data);
	}
	public function signup()
	{
		$this->form_validation->set_rules('c_name', 'Name', 'required');
		$this->form_validation->set_rules('c_mobile', 'Mobile', 'required|min_length[9]|max_length[12]');
		$this->form_validation->set_rules('c_email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('c_pwd', 'Password', 'required');
		$this->form_validation->set_rules('c_address', 'Address', 'required');
		if($this->form_validation->run() == FALSE) 
		{
		  $this->session->set_flashdata('warningmessage', validation_errors());
		  redirect('/');
		}
		else 
		{ 
			$testxss = xssclean($_POST);
			if($testxss){
				$exist = $this->db->select('*')->from('customers')->where('c_email',$this->input->post('c_email'))->get()->result_array();
				if(count($exist)==0) {
					$response = $this->customer_model->add_customer($this->input->post());
					if($response) {
						$this->session->set_flashdata('successmessage', 'Conta criada com sucesso..');
					} else {
						$this->session->set_flashdata('warningmessage', 'Alguma coisa deu errado. Por favor tente outra vez..');
					}
				} else {
					$this->session->set_flashdata('warningmessage', 'Já existe uma conta com o mesmo e-mail. Por favor entre..');
				}
				redirect('/');
			} else {
				$this->session->set_flashdata('warningmessage', 'Erro! Sua entrada não é permitida. Por favor, tente novamente');
				redirect('/');
			}
		}
	}
	public function login() 
	{
		$this->db->where('c_email', $this->input->post('username'));
        $this->db->where('c_pwd', md5($this->input->post('password')));
        $query = $this->db->get("customers");
		if ($query->num_rows() >= 1) {
		 	$result = $query->row_array();
			$session_data = array('c_id' => $result['c_id'],
								  'c_name' => $result['c_name'],
								  'c_email' => $result['c_email']); 
			if($result['c_isactive']==0) {
				$this->session->set_flashdata('warningmessage', 'Usuário não ativo. Entre em contato com o administrador');
				redirect('/');
			} else {
				$this->session->set_flashdata('successmessage', 'Você se conectou com sucesso..');
				$this->session->set_userdata('session_data_fr', $session_data);
				redirect('/');
			}
		} else {
			$this->session->set_flashdata('warningmessage', 'E-mail ou senha inválidos!');
			redirect('/');
		}
	}
	public function logout() {
		$sess_array = array('c_id' => '');
		$this->session->unset_userdata('session_data_fr', $sess_array);
		$this->session->set_flashdata('successmessage', 'Logout com sucesso!');
		redirect('/');
	}
	public function book() {
		$this->load->model('trips_model');
		if($this->input->post('t_created_by')!='') {
			$this->form_validation->set_rules('t_trip_fromlocation', 'From Location', 'required');
			$this->form_validation->set_rules('t_trip_tolocation', 'To Location', 'required');
			$this->form_validation->set_rules('t_start_date', 'Date', 'required');
			if($this->form_validation->run() == FALSE) {
			  $this->session->set_flashdata('warningmessage', validation_errors());
			  redirect('/');
			} else {
				$response = $this->trips_model->add_trips($this->input->post());
				$bookingemail = $this->input->post('bookingemail');
				if(isset($bookingemail)) {
					$this->sendtripemail($this->input->post());
				}
				if($response) {
					$this->session->set_flashdata('successmessage', 'Reserva concluída com sucesso. Entraremos em contato em breve..');
				} else {
					$this->session->set_flashdata('warningmessage', 'Erro inesperado..Tente novamente');
				}
				redirect('/');
			}
		} else {
			$this->session->set_flashdata('warningmessage', 'Faça o login antes de tentar reservar..');
			redirect('/');
		}
	}
	public function sendtripemail($data) {
		$this->load->model('email_model');	
		$gettemplate = $this->db->select('*')->from('email_template')->where('et_name','booking')->get()->result_array();
		if(!empty($gettemplate)) {
		    $emailcontent = $gettemplate[0]['et_body'];
			$value = '<b>Trip Details :</b><br><br> '.$data['t_trip_fromlocation']. ' <br><b>to</b><br> ' . $data['t_trip_tolocation']. ' <br>on<br> ' .$data['t_start_date'];
			$body = str_replace('{{bookingdetails}}', $value, $emailcontent);
			$email = $this->email_model->sendemail($data['bookingemail'],$gettemplate[0]['et_subject'],$body);
		}
	}
	
}
