<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Creditfuel extends CI_Controller {

	 function __construct()
     {
          parent::__construct();
          $this->load->database();
          $this->load->model('Creditfuel_model');
          $this->load->helper(array('form', 'url','string'));
          $this->load->library('form_validation');
          $this->load->library('session');
		  
     }

	public function index()
	{
		$data['Creditfuel'] = $this->Creditfuel_model->getall_fuel();

		//var_dump($data['Creditfuel']);
		$this->template->template_render('Creditfuel',$data);
	}
	public function addcreditfuel()
	{
		$this->load->model('trips_model');
		$data['driverlist'] = $this->trips_model->getall_driverlist();
		$data['vechiclelist'] = $this->trips_model->getall_vechicle();
		$this->template->template_render('Creditfuel_add',$data);
	}
	public function insertcreditfuel()
	{
		$testxss = xssclean($_POST);
		if($testxss){
			var_dump($this->input->post());
			$response = $this->Creditfuel_model->add_Creditfuel($this->input->post());
			if($response) {
				$is_include = $this->input->post('exp');
				if(isset($is_include)) {
					$addincome = array('ie_v_id'=>$this->input->post('v_id'),'ie_date'=>date('Y-m-d'),'ie_type'=>'expense','ie_description'=>'Added fuel - '.$this->input->post('v_fuelcomments'),'ie_amount'=>$this->input->post('v_fuelprice'),'ie_created_date'=>date('Y-m-d'));
					$this->db->insert('incomeexpense',$addincome);
				}
				$this->session->set_flashdata('successmessage', 'Detalhes do Cartão adicionados com sucesso..');
			} else {
				$this->session->set_flashdata('warningmessage', 'Algo deu errado. Tente novamente');
			}
			redirect('Creditfuel');
		} else {
			$this->session->set_flashdata('warningmessage', 'Erro! Sua entrada não é permitida. Por favor, tente novamente');
			redirect('Creditfuel');
		}
	}
	public function editcreditfuel()
	{
		$f_id = $this->uri->segment(3);
		$this->load->model('trips_model');
		$data['vechiclelist'] = $this->trips_model->getall_vechicle();
		$data['driverlist'] = $this->trips_model->getall_driverlist();
		$data['fueldetails'] = $this->Creditfuel_model->crediteditfuel($f_id);
		$this->template->template_render('Creditfuel_add',$data);
	}

	public function updatecreditfuel()
	{
		//var_dump($this->input->post());
		$testxss = xssclean($_POST);
		if($testxss){
			$response = $this->Creditfuel_model->updatefuel($this->input->post());
			if($response) {
				$this->session->set_flashdata('successmessage', 'Detalhes de cartão atualizados com sucesso..');
			    redirect('creditfuel');
			} else
			{
				$this->session->set_flashdata('warningmessage', 'Algo deu errado..Tente novamente');
			    redirect('creditfuel');
			}
		} else {
			$this->session->set_flashdata('warningmessage', 'Erro! Sua entrada não é permitida. Por favor, tente novamente');
			redirect('creditfuel');
		}
	}
}
